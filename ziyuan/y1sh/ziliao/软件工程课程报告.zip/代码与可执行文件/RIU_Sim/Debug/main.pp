# FIXED

main.obj: ../main.c
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_Examples.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_GlobalPrototypes.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_EPwm_defines.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_Dma_defines.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_I2c_defines.h
main.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_DefaultIsr.h
main.obj: ../hal_sim.h
main.obj: ../riu_common.h
main.obj: ../pos_id.h
main.obj: ../pubit.h
main.obj: ../cycle_task.h
main.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdio.h
main.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/linkage.h
main.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdarg.h

../main.c: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_Examples.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_GlobalPrototypes.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_EPwm_defines.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_Dma_defines.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_I2c_defines.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include/DSP2833x_DefaultIsr.h: 
../hal_sim.h: 
../riu_common.h: 
../pos_id.h: 
../pubit.h: 
../cycle_task.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdio.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/linkage.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdarg.h: 
