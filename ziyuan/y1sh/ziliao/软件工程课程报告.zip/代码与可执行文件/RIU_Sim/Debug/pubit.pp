# FIXED

pubit.obj: ../pubit.c
pubit.obj: ../pubit.h
pubit.obj: ../riu_common.h
pubit.obj: ../hal_sim.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h
pubit.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h
pubit.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdio.h
pubit.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/linkage.h
pubit.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdarg.h

../pubit.c: 
../pubit.h: 
../riu_common.h: 
../hal_sim.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdio.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/linkage.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdarg.h: 
