# FIXED

hal_sim.obj: ../hal_sim.c
hal_sim.obj: ../hal_sim.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h
hal_sim.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h
hal_sim.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/string.h
hal_sim.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/linkage.h

../hal_sim.c: 
../hal_sim.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/string.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/linkage.h: 
