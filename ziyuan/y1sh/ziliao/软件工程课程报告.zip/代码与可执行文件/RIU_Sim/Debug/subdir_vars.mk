################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../28335_RAM_lnk.cmd 

ASM_SRCS += \
../DSP2833x_ADC_cal.asm \
../DSP2833x_usDelay.asm 

C_SRCS += \
../DSP2833x_CpuTimers.c \
../DSP2833x_DefaultIsr.c \
../DSP2833x_GlobalVariableDefs.c \
../DSP2833x_Gpio.c \
../DSP2833x_PieCtrl.c \
../DSP2833x_PieVect.c \
../DSP2833x_Sci.c \
../DSP2833x_SysCtrl.c \
../cycle_task.c \
../hal_sim.c \
../main.c \
../pos_id.c \
../pubit.c 

OBJS += \
./DSP2833x_ADC_cal.obj \
./DSP2833x_CpuTimers.obj \
./DSP2833x_DefaultIsr.obj \
./DSP2833x_GlobalVariableDefs.obj \
./DSP2833x_Gpio.obj \
./DSP2833x_PieCtrl.obj \
./DSP2833x_PieVect.obj \
./DSP2833x_Sci.obj \
./DSP2833x_SysCtrl.obj \
./DSP2833x_usDelay.obj \
./cycle_task.obj \
./hal_sim.obj \
./main.obj \
./pos_id.obj \
./pubit.obj 

ASM_DEPS += \
./DSP2833x_ADC_cal.pp \
./DSP2833x_usDelay.pp 

C_DEPS += \
./DSP2833x_CpuTimers.pp \
./DSP2833x_DefaultIsr.pp \
./DSP2833x_GlobalVariableDefs.pp \
./DSP2833x_Gpio.pp \
./DSP2833x_PieCtrl.pp \
./DSP2833x_PieVect.pp \
./DSP2833x_Sci.pp \
./DSP2833x_SysCtrl.pp \
./cycle_task.pp \
./hal_sim.pp \
./main.pp \
./pos_id.pp \
./pubit.pp 

C_DEPS__QUOTED += \
"DSP2833x_CpuTimers.pp" \
"DSP2833x_DefaultIsr.pp" \
"DSP2833x_GlobalVariableDefs.pp" \
"DSP2833x_Gpio.pp" \
"DSP2833x_PieCtrl.pp" \
"DSP2833x_PieVect.pp" \
"DSP2833x_Sci.pp" \
"DSP2833x_SysCtrl.pp" \
"cycle_task.pp" \
"hal_sim.pp" \
"main.pp" \
"pos_id.pp" \
"pubit.pp" 

OBJS__QUOTED += \
"DSP2833x_ADC_cal.obj" \
"DSP2833x_CpuTimers.obj" \
"DSP2833x_DefaultIsr.obj" \
"DSP2833x_GlobalVariableDefs.obj" \
"DSP2833x_Gpio.obj" \
"DSP2833x_PieCtrl.obj" \
"DSP2833x_PieVect.obj" \
"DSP2833x_Sci.obj" \
"DSP2833x_SysCtrl.obj" \
"DSP2833x_usDelay.obj" \
"cycle_task.obj" \
"hal_sim.obj" \
"main.obj" \
"pos_id.obj" \
"pubit.obj" 

ASM_DEPS__QUOTED += \
"DSP2833x_ADC_cal.pp" \
"DSP2833x_usDelay.pp" 

ASM_SRCS__QUOTED += \
"../DSP2833x_ADC_cal.asm" \
"../DSP2833x_usDelay.asm" 

C_SRCS__QUOTED += \
"../DSP2833x_CpuTimers.c" \
"../DSP2833x_DefaultIsr.c" \
"../DSP2833x_GlobalVariableDefs.c" \
"../DSP2833x_Gpio.c" \
"../DSP2833x_PieCtrl.c" \
"../DSP2833x_PieVect.c" \
"../DSP2833x_Sci.c" \
"../DSP2833x_SysCtrl.c" \
"../cycle_task.c" \
"../hal_sim.c" \
"../main.c" \
"../pos_id.c" \
"../pubit.c" 


