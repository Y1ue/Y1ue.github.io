# FIXED

DSP2833x_GlobalVariableDefs.obj: ../DSP2833x_GlobalVariableDefs.c
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h
DSP2833x_GlobalVariableDefs.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h

../DSP2833x_GlobalVariableDefs.c: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h: 
