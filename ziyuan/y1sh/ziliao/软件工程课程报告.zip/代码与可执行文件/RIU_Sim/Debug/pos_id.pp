# FIXED

pos_id.obj: ../pos_id.c
pos_id.obj: ../pos_id.h
pos_id.obj: ../riu_common.h
pos_id.obj: ../hal_sim.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h
pos_id.obj: D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h
pos_id.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdio.h
pos_id.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/linkage.h
pos_id.obj: D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdarg.h

../pos_id.c: 
../pos_id.h: 
../riu_common.h: 
../hal_sim.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Device.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Adc.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DevEmu.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_CpuTimers.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECan.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_ECap.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_DMA.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EPwm.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_EQep.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Gpio.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_I2c.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Mcbsp.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_PieVect.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Spi.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Sci.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_SysCtrl.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_XIntrupt.h: 
D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include/DSP2833x_Xintf.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdio.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/linkage.h: 
D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include/stdarg.h: 
