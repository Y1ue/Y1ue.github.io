################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
DSP2833x_ADC_cal.obj: ../DSP2833x_ADC_cal.asm $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_ADC_cal.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_CpuTimers.obj: ../DSP2833x_CpuTimers.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_CpuTimers.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_DefaultIsr.obj: ../DSP2833x_DefaultIsr.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_DefaultIsr.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_GlobalVariableDefs.obj: ../DSP2833x_GlobalVariableDefs.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_GlobalVariableDefs.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_Gpio.obj: ../DSP2833x_Gpio.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_Gpio.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_PieCtrl.obj: ../DSP2833x_PieCtrl.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_PieCtrl.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_PieVect.obj: ../DSP2833x_PieVect.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_PieVect.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_Sci.obj: ../DSP2833x_Sci.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_Sci.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_SysCtrl.obj: ../DSP2833x_SysCtrl.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_SysCtrl.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

DSP2833x_usDelay.obj: ../DSP2833x_usDelay.asm $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="DSP2833x_usDelay.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

cycle_task.obj: ../cycle_task.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="cycle_task.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

hal_sim.obj: ../hal_sim.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="hal_sim.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

main.obj: ../main.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="main.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

pos_id.obj: ../pos_id.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="pos_id.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

pubit.obj: ../pubit.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -mt --float_support=fpu32 -O1 --include_path="D:/software/CCS5.5/CCS/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_headers/include" --include_path="D:/software/CCS5.5/workspace/LIB/DSP2833x_common/include" -g --diag_warning=225 --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="pubit.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '


