import pandas as pd
from sklearn.model_selection import train_test_split

data_path = "data/diabetes_data_processed.csv"
df = pd.read_csv(data_path)
print(f"成功读取数据：{data_path}")
print("="*60)

X = df.drop(columns=['class'])
y = df['class']

X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.3,
    random_state=1,
    stratify=y
)

train_df = pd.concat([X_train, y_train], axis=1).reset_index(drop=True)
test_df = pd.concat([X_test, y_test], axis=1).reset_index(drop=True)

print(f"数据7:3分层划分完成！")
print("="*60)

train_save_path = "data/diabetes_train.csv"
test_save_path = "data/diabetes_test.csv"

train_df.to_csv(train_save_path, index=False, encoding='utf-8')
test_df.to_csv(test_save_path, index=False, encoding='utf-8')

print(f"划分后数据已保存！")
print(f"训练集保存路径：{train_save_path}")
print(f"测试集保存路径：{test_save_path}")
print("="*60)