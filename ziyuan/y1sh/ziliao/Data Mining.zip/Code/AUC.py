import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import joblib
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score, roc_curve
import matplotlib.pyplot as plt


dt_model_path = "model/diabetes_dt_model.pkl"   # 修改模型
scaler_path = "diabetes_scaler.pkl"
dt_model = joblib.load(dt_model_path)
scaler = joblib.load(scaler_path)
significant_features = ['gender', 'polyuria', 'polydipsia', 'sudden weight loss', 'weakness', 'polyphagia', 'genital thrush', 'visual blurring', 'irritability', 'partial paresis', 'muscle stiffness', 'alopecia']

print("决策树模型及配套文件加载完成！")
print("="*70)

test_data_path = "data/diabetes_test.csv"
test_df = pd.read_csv(test_data_path)

X_test = test_df[significant_features].values
y_test = test_df['class'].values
X_test_scaled = scaler.transform(X_test)

print(f"测试集预处理完成！形状：{X_test_scaled.shape}")
print(f"测试集糖尿病样本比例：{test_df['class'].mean():.4f}")
print("="*70)

y_test_pred = dt_model.predict(X_test_scaled)
try:
    y_test_score = dt_model.predict_proba(X_test_scaled)[:, 1]
    score_type = "概率值"
except AttributeError:
    y_test_score = dt_model.decision_function(X_test_scaled)
    y_test_score = (y_test_score - y_test_score.min()) / (y_test_score.max() - y_test_score.min())
    score_type = "归一化决策函数值"
    print("模型未开启概率输出，改用决策函数计算AUC/ROC（结果等价）")

acc = accuracy_score(y_test, y_test_pred)
auc = roc_auc_score(y_test, y_test_score)

print("决策树模型核心评估指标")
print("-"*50)
print(f"整体准确率：{acc:.4f}（{acc*100:.2f}%）")
print(f"AUC值（区分能力）：{auc:.4f}")
print("="*70)


plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 150

fpr, tpr, thresholds = roc_curve(y_test, y_test_score)
plt.figure(figsize=(10, 8))
plt.plot(fpr, tpr, color='#2E86AB', lw=2, label=f'决策树模型 (AUC = {auc:.4f})')
plt.plot([0, 1], [0, 1], color='#E63946', lw=2, linestyle='--', label='随机猜测 (AUC = 0.5)')

plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('假阳性率 (FPR)', fontsize=12, fontweight='bold')
plt.ylabel('真阳性率 (TPR)', fontsize=12, fontweight='bold')
plt.title('糖尿病预测决策树模型 ROC曲线', fontsize=16, fontweight='bold', pad=20)
plt.legend(loc='lower right', fontsize=11)
plt.grid(alpha=0.3)

plt.savefig('ROC/diabetes_dt_roc_curve.png', bbox_inches='tight')
plt.close()

print("ROC曲线绘制完成！")
