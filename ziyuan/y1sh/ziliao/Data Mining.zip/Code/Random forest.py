import warnings
warnings.filterwarnings('ignore')
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

import joblib

train_df = pd.read_csv('data/diabetes_train.csv')
test_df = pd.read_csv('data/diabetes_test.csv')
target_col = 'class'
significant_features = ['gender', 'polyuria', 'polydipsia', 'sudden weight loss', 'weakness', 'polyphagia', 'genital thrush', 'visual blurring', 'irritability', 'partial paresis', 'muscle stiffness', 'alopecia']

X_train = train_df[significant_features].values
X_test = test_df[significant_features].values
y_train = train_df[target_col].values
y_test = test_df[target_col].values

scaler = joblib.load('diabetes_scaler.pkl')
print("成功加载预设标准化器：diabetes_scaler.pkl")
X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("数据标准化完成")
print("="*70)

rf_classifier = RandomForestClassifier(
    n_estimators=100,        # 决策树数量，默认100（数量越多效果越稳，耗时稍增）
    max_depth=6,             # 单棵树最大深度，防止过拟合
    min_samples_split=10,    # 节点分裂最小样本数，辅助防过拟合
    random_state=1,          # 固定随机种子，保证训练结果可复现
    n_jobs=-1                # 启用所有CPU核心，加速训练（大数据集效果明显）
)

print("开始训练随机森林模型...（集成100棵决策树，启用多核加速）")
rf_classifier.fit(X_train_scaled, y_train)
print("随机森林模型训练完成！")
print("="*70)

y_test_pred = rf_classifier.predict(X_test_scaled)
accuracy = accuracy_score(y_test, y_test_pred)
class_report = classification_report(y_test, y_test_pred)

print(f"随机森林模型测试集准确率：{accuracy:.4f}（{accuracy*100:.2f}%）")
print("-"*50)
print("详细分类报告（精准率/召回率/F1值）：")
print(class_report)
print("="*70)

feat_importance = pd.DataFrame({
    '特征名称': significant_features,
    '重要性': rf_classifier.feature_importances_
})

feat_importance = feat_importance.sort_values(by='重要性', ascending=False)
print("随机森林特征重要性排序（从高到低，集成所有树的贡献）：")
print(feat_importance)
print("="*70)

rf_model_path = 'model/diabetes_rf_model.pkl'
joblib.dump(rf_classifier, rf_model_path)

print("训练结果已保存：")
print(f"1. 随机森林模型：{rf_model_path}")
print("="*70)
print("随机森林模型全流程训练完成！")