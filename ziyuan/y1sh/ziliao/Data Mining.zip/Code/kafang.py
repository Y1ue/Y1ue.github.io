import warnings
warnings.filterwarnings('ignore')
import pandas as pd
from scipy.stats import chi2_contingency


df = pd.read_csv('diabetes_data_processed.csv')
target_col = 'class'
feature_cols = [col for col in df.columns if col != target_col]

chi2_results = []

for feat in feature_cols:
    contingency_table = pd.crosstab(df[feat], df[target_col])
    chi2, pval, dof, exp_freq = chi2_contingency(contingency_table)
    is_significant = '是' if pval < 0.05 else '否'
    chi2_results.append({
        '特征列': feat,
        '卡方值(chi2)': round(chi2, 4),  
        'p值(p-value)': round(pval, 6),
        '自由度(dof)': dof,
        '是否与糖尿病显著关联(α=0.05)': is_significant
    })
chi2_result_df = pd.DataFrame(chi2_results)
print(chi2_result_df)
chi2_result_df.to_csv('糖尿病特征卡方检验结果.csv', index=False, encoding='utf-8-sig')


