import warnings
warnings.filterwarnings('ignore')
import pandas as pd


df = pd.read_csv('Project 4 - diabetes_data.csv')
df['gender'] = df['gender'].map({'Male':1,'Female':0})
df['class'] = df['class'].map({'Positive':1,'Negative':0})
df['polyuria'] = df['polyuria'].map({'Yes':1,'No':0})
df['polydipsia'] = df['polydipsia'].map({'Yes':1,'No':0})
df['sudden weight loss'] = df['sudden weight loss'].map({'Yes':1,'No':0})
df['weakness'] = df['weakness'].map({'Yes':1,'No':0})
df['polyphagia'] = df['polyphagia'].map({'Yes':1,'No':0})
df['genital thrush'] = df['genital thrush'].map({'Yes':1,'No':0})
df['visual blurring'] = df['visual blurring'].map({'Yes':1,'No':0})
df['itching'] = df['itching'].map({'Yes':1,'No':0})
df['irritability'] = df['irritability'].map({'Yes':1,'No':0})
df['delayed healing'] = df['delayed healing'].map({'Yes':1,'No':0})
df['partial paresis'] = df['partial paresis'].map({'Yes':1,'No':0})
df['muscle stiffness'] = df['muscle stiffness'].map({'Yes':1,'No':0})
df['alopecia'] = df['alopecia'].map({'Yes':1,'No':0})
df['obesity'] = df['obesity'].map({'Yes':1,'No':0})
df['age'] = df['age'].apply(lambda x: 1 if x >= 50 else 0)

df.to_csv('diabetes_data_processed.csv', index=False)

print("Work done!")
