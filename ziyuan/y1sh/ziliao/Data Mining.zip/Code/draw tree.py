import warnings
warnings.filterwarnings('ignore')
import joblib
from sklearn.tree import plot_tree, export_graphviz, export_text
import matplotlib.pyplot as plt

model_path = 'model/diabetes_dt_model.pkl'
dt_model = joblib.load(model_path)
significant_features = ['gender', 'polyuria', 'polydipsia', 'sudden weight loss', 'weakness', 'polyphagia', 'genital thrush', 'visual blurring', 'irritability', 'partial paresis', 'muscle stiffness', 'alopecia']
print(f"成功加载训练好的决策树模型：{model_path}")

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 150

plt.figure(figsize=(25, 15))
plot_tree(
    dt_model,
    feature_names=significant_features,
    class_names=['无糖尿病(0)', '有糖尿病(1)'],
    filled=True,
    rounded=True,
    fontsize=11,
    precision=2
)
plt.title('糖尿病预测决策树模型（已训练完成）', fontsize=20, pad=30, fontweight='bold')

plt.savefig('diabetes_dt_visualization.png', bbox_inches='tight')
plt.close()
print(" Matplotlib可视化图已保存：diabetes_dt_visualization.png")



