import warnings
warnings.filterwarnings('ignore')
import pandas as pd

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, accuracy_score

import joblib

train_df = pd.read_csv('data/diabetes_train.csv')
test_df = pd.read_csv('data/diabetes_test.csv')
target_col = 'class'
significant_features = ['gender', 'polyuria', 'polydipsia', 'sudden weight loss', 'weakness', 'polyphagia', 'genital thrush', 'visual blurring', 'irritability', 'partial paresis', 'muscle stiffness', 'alopecia']

X_train = train_df[significant_features].values
X_test = test_df[significant_features].values
y_train = train_df[target_col].values
y_test = test_df[target_col].values


scaler = joblib.load('diabetes_scaler.pkl')
print("成功加载预设标准化器：diabetes_scaler.pkl")

X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("数据标准化完成！")
print("="*70)

dt_classifier = DecisionTreeClassifier(
    random_state=1,          # 固定随机种子，保证结果可复现
    max_depth=6,             # 限制树深度，防止过拟合（关键参数）
    min_samples_split=10,    # 节点分裂最小样本数，防止过拟合
    criterion='gini'         # 特征选择准则：gini=基尼系数，entropy=信息熵
)

print("开始训练决策树模型...")
dt_classifier.fit(X_train_scaled, y_train)
print("决策树模型训练完成！")
print("="*70)

y_test_pred = dt_classifier.predict(X_test_scaled)

accuracy = accuracy_score(y_test, y_test_pred)
class_report = classification_report(y_test, y_test_pred)

print(f"决策树模型测试集准确率：{accuracy:.4f}（{accuracy*100:.2f}%）")
print("-"*50)
print("决策树模型详细分类报告（精准率/召回率/F1值）：")
print(class_report)
print("="*70)


feat_importance = pd.DataFrame({
    '特征名称': significant_features,
    '重要性': dt_classifier.feature_importances_
})
feat_importance = feat_importance.sort_values(by='重要性', ascending=False)
print("决策树特征重要性排序（从高到低）：")
print(feat_importance)
print("="*70)

model_path = 'model/diabetes_dt_model.pkl'

joblib.dump(dt_classifier, model_path)

print("训练结果已全部保存：")
print(f"1. 决策树模型：{model_path}")
print("="*70)
print("整个流程执行完成！")