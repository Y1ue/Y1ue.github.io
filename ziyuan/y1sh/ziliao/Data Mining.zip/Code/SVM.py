import warnings
warnings.filterwarnings('ignore')
import pandas as pd

from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, accuracy_score

import joblib


train_df = pd.read_csv('data/diabetes_train.csv')
test_df = pd.read_csv('data/diabetes_test.csv')
target_col = 'class'
significant_features = ['gender', 'polyuria', 'polydipsia', 'sudden weight loss', 'weakness', 'polyphagia', 'genital thrush', 'visual blurring', 'irritability', 'partial paresis', 'muscle stiffness', 'alopecia']


X_train = train_df[significant_features].values
X_test = test_df[significant_features].values
y_train = train_df[target_col].values
y_test = test_df[target_col].values

scaler = joblib.load('diabetes_scaler.pkl')
print("成功加载预设标准化器：diabetes_scaler.pkl")

# scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("数据标准化完成！")
print("="*70)


svm_classifier = SVC(kernel='rbf', random_state=1)
print("开始训练SVM模型（使用标准化数据+显著特征）...")
svm_classifier.fit(X_train_scaled, y_train)
print("SVM模型训练完成！")
print("="*70)


y_test_pred = svm_classifier.predict(X_test_scaled)

accuracy = accuracy_score(y_test, y_test_pred)  # 准确率
class_report = classification_report(y_test, y_test_pred)  # 精准率、召回率、F1值

print(f"SVM模型测试集准确率：{accuracy:.4f}（{accuracy*100:.2f}%）")
print("-"*50)
print("SVM模型详细分类报告（精准率/召回率/F1值）：")
print(class_report)
print("="*70)

model_path = 'model/diabetes_svm_model.pkl'

# scaler_path = 'diabetes_scaler.pkl'

joblib.dump(svm_classifier, model_path)
# joblib.dump(scaler, scaler_path)


print("训练结果已全部保存：")
print(f"SVM模型：{model_path}")
# print(f"数据标准化器：{scaler_path}")
print("="*70)
print("整个流程执行完成！")


