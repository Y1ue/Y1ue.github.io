import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import joblib
from sklearn.metrics import classification_report, accuracy_score

model_path = "model/diabetes_xgb_model.pkl"     # 此处修改模型路径
scaler_path = "diabetes_scaler.pkl"

model = joblib.load(model_path)
scaler = joblib.load(scaler_path)
significant_features = ['gender', 'polyuria', 'polydipsia', 'sudden weight loss', 'weakness', 'polyphagia', 'genital thrush', 'visual blurring', 'irritability', 'partial paresis', 'muscle stiffness', 'alopecia']

print(f"加载模型：{model_path}")
print(f"加载标准化器：{scaler_path}")
print("="*70)

test_data_path = "data/diabetes_test.csv"       # 加载测试数据
test_df = pd.read_csv(test_data_path)
print(f"成功读取测试集：{test_data_path}")
print(f"测试集糖尿病（class=1）比例：{test_df['class'].mean():.4f}")
print("="*70)

X_test = test_df[significant_features].values
y_test = test_df['class'].values

X_test_scaled = scaler.transform(X_test)
print("测试集数据预处理完成！")
print("="*70)

y_test_pred = model.predict(X_test_scaled)

# 计算核心评估指标
accuracy = accuracy_score(y_test, y_test_pred)  # 整体准确率
class_report = classification_report(
    y_test, y_test_pred,
    target_names=['无糖尿病(0)', '有糖尿病(1)'],
    digits=4
)

# 打印完整评估结果
print("模型测试集完整评估结果：")
print("-"*50)
print(f"模型整体准确率：{accuracy:.4f}（{accuracy*100:.2f}%）")
print("-"*50)
print("精准率/召回率/F1值详细报告：")
print(class_report)
print("="*70)
print("模型测试集评估完成！所有指标已输出。")