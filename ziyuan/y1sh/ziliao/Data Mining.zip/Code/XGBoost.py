import warnings
warnings.filterwarnings('ignore')
import pandas as pd
from sklearn.metrics import classification_report, accuracy_score
import xgboost as xgb

import joblib

train_df = pd.read_csv('data/diabetes_train.csv')
test_df = pd.read_csv('data/diabetes_test.csv')
target_col = 'class'
significant_features = ['gender', 'polyuria', 'polydipsia', 'sudden weight loss', 'weakness', 'polyphagia', 'genital thrush', 'visual blurring', 'irritability', 'partial paresis', 'muscle stiffness', 'alopecia']

X_train = train_df[significant_features].values
X_test = test_df[significant_features].values
y_train = train_df[target_col].values
y_test = test_df[target_col].values


scaler = joblib.load('diabetes_scaler.pkl')
print("成功加载预设标准化器：diabetes_scaler.pkl")
X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("数据标准化完成")
print("="*70)

xgb_classifier = xgb.XGBClassifier(
    objective='binary:logistic',  # 二分类任务目标函数（逻辑回归）
    n_estimators=100,             # 弱学习器（决策树）数量，默认100
    max_depth=6,                  # 单棵树最大深度，核心防过拟合参数
    learning_rate=0.1,            # 学习率（步长），越小越稳健，默认0.1
    subsample=0.8,                # 训练每棵树的样本采样率，防止过拟合
    colsample_bytree=0.8,         # 训练每棵树的特征采样率，防止过拟合
    random_state=1,               # 固定随机种子，保证结果可复现
    n_jobs=-1,                    # 启用所有CPU核心，加速训练
    eval_metric='logloss'         # 二分类评估指标（对数损失）
)

print("开始训练XGBoost模型...")
xgb_classifier.fit(
    X_train_scaled, y_train,
    eval_set=[(X_test_scaled, y_test)],  # 训练过程中验证测试集
    early_stopping_rounds=10,            # 早停机制：10轮无提升则停止，防止过拟合
    verbose=False                        # 关闭训练过程打印（如需查看可改为True）
)
print("XGBoost模型训练完成！")
print("="*70)

y_test_pred = xgb_classifier.predict(X_test_scaled)
y_test_pred_proba = xgb_classifier.predict_proba(X_test_scaled)[:, 1]

accuracy = accuracy_score(y_test, y_test_pred)
class_report = classification_report(y_test, y_test_pred, target_names=['无糖尿病(0)', '有糖尿病(1)'])

print(f"XGBoost模型测试集准确率：{accuracy:.4f}（{accuracy*100:.2f}%）")
print("-"*50)
print("详细分类报告（精准率/召回率/F1值）：")
print(class_report)
print("="*70)

feat_importance = pd.DataFrame({
    '特征名称': significant_features,
    '特征重要性': xgb_classifier.feature_importances_
})

feat_importance = feat_importance.sort_values(by='特征重要性', ascending=False).reset_index(drop=True)
print("XGBoost特征重要性排序（从高到低，集成所有树的贡献）：")
print(feat_importance)
print("="*70)

xgb_model_path = 'model/diabetes_xgb_model.pkl'
joblib.dump(xgb_classifier, xgb_model_path)

print("训练结果已保存：")
print(f"1. XGBoost模型：{xgb_model_path}")
print(f"（预设标准化器 diabetes_scaler.pkl 已存在，无需重复保存）")
print("="*70)
print("XGBoost模型全流程训练完成！（当前最优性能模型）")