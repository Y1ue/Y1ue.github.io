import torch
from torch.utils.data import DataLoader
from torch.utils.data.dataloader import _BaseDataLoaderIter

class _MSDataLoaderIter(_BaseDataLoaderIter):

    def __init__(self, loader):
        super(_MSDataLoaderIter, self).__init__(loader)
        self.dataset = loader.dataset
        self.scale = loader.scale
        self.collate_fn = loader.collate_fn
        self.batch_sampler = loader.batch_sampler
        self._sampler_iter = iter(self.batch_sampler)

    def _next_data(self):
        try:
            batch_indices = next(self._sampler_iter)
        except StopIteration:
            raise StopIteration

        try:
            idx_scale = 0
            if len(self.scale) > 1 and self.dataset.train:
                idx_scale = torch.randint(0, len(self.scale), (1,)).item()
                self.dataset.set_scale(idx_scale)
            samples = self.collate_fn([self.dataset[i] for i in batch_indices])
            samples.append(idx_scale)
            return samples
        except Exception as e:
            raise e


class MSDataLoader(DataLoader):
    def __init__(self, cfg, *args, **kwargs):
        super(MSDataLoader, self).__init__(
            *args, **kwargs, num_workers=0
        )
        self.scale = cfg.scale

    def __iter__(self):
        return _MSDataLoaderIter(self)