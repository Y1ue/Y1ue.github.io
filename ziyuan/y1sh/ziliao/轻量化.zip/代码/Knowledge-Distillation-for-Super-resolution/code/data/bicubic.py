import cv2
import os
from pathlib import Path


def batch_bicubic_downsample(input_dir, output_dir, scale_factor):
    """
    对输入文件夹中的所有图像进行批量双三次下采样，并保存到输出文件夹。

    :param input_dir: 包含原始图像的文件夹路径。
    :param output_dir: 用于保存下采样后图像的文件夹路径。
    :param scale_factor: 缩放因子 (例如 0.5 表示缩小到原来的一半)。
    """
    # 1. 检查输入文件夹是否存在
    if not os.path.isdir(input_dir):
        print(f"错误：输入文件夹 '{input_dir}' 不存在。")
        return

    # 2. 创建输出文件夹（如果不存在）
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    print(f"处理后的图像将保存到: {output_dir}")

    # 3. 定义支持的图像文件扩展名
    supported_formats = ('.png', '.jpg', '.jpeg', '.bmp', '.tiff')
    downscale_ratio = int(1 / scale_factor)

    # 4. 遍历输入文件夹中的所有文件
    for filename in os.listdir(input_dir):
        # 检查文件是否为图像
        if filename.lower().endswith(supported_formats):

            file_stem, file_ext = os.path.splitext(filename)
            new_filename = f"{file_stem}x{downscale_ratio}{file_ext}"

            input_path = os.path.join(input_dir, filename)
            output_path = os.path.join(output_dir, new_filename)

            try:
                # 读取图像
                image = cv2.imread(input_path)
                if image is None:
                    print(f"警告：无法读取图像 {filename}，已跳过。")
                    continue

                # 获取原始图像尺寸
                original_height, original_width = image.shape[:2]

                # 计算下采样后的新尺寸
                new_width = int(original_width * scale_factor)
                new_height = int(original_height * scale_factor)

                # 执行双三次下采样
                downsampled_image = cv2.resize(
                    image,
                    (new_width, new_height),
                    interpolation=cv2.INTER_CUBIC
                )

                # 保存下采样后的图像
                cv2.imwrite(output_path, downsampled_image)
                print(f"已处理: {filename} -> {new_filename} ({original_width}x{original_height} -> {new_width}x{new_height})")

            except Exception as e:
                print(f"处理 {filename} 时发生错误: {e}")

    print("\n所有图像处理完成！")


# --- 如何使用 ---
if __name__ == "__main__":
    # --- 请在这里修改你的配置 ---
    # 输入文件夹路径
    INPUT_FOLDER = "./dataset/benchmark/manga109/HR"
    # 输出文件夹路径
    OUTPUT_FOLDER = "./dataset/benchmark/manga109/LR_bicubic/X4"
    # 缩放因子 (例如 0.5 表示缩小到50%)
    SCALE_FACTOR = 1/4

    # 调用函数执行批量处理
    batch_bicubic_downsample(INPUT_FOLDER, OUTPUT_FOLDER, SCALE_FACTOR)